# OCR Scanner Pro - GitHub Actions Build Kit

This kit adds a GitHub Actions workflow for:
- Debug/test APK build on pushes to `main` and manual workflow runs.
- Signed release APK build on manual runs, only after signing secrets are configured.

## Expected repository layout

The source ZIP must be extracted at the repository root so this folder exists:
`OCRScanner_Pro/`

Copy `.github/workflows/android-apk.yml` to the repository path:
`.github/workflows/android-apk.yml`

Replace:
`OCRScanner_Pro/app/build.gradle.kts`
with the supplied `app-build.gradle.kts` (rename it to `build.gradle.kts`).

## Build test APK
Open GitHub repository > Actions > Android APK builds > Run workflow.
The debug APK is uploaded as artifact `OCRScanner-Pro-debug`.

## Release signing
Do not commit the `.jks` keystore or passwords to the repository.
Create a long-lived signing key in a trusted private environment and keep a secure backup.
Add these repository Actions secrets:
- ANDROID_KEYSTORE_BASE64 (base64-encoded JKS bytes, one line)
- ANDROID_KEYSTORE_PASSWORD
- ANDROID_KEY_ALIAS
- ANDROID_KEY_PASSWORD

Then run the workflow manually. If the secrets are present, it also builds and uploads
`OCRScanner-Pro-release`.

Never paste the keystore or passwords into chat, source files, commits, issues, or public logs.
Loss of the release keystore can prevent future APK updates from being accepted as updates
to the same app. Keep a backup with a trusted adult if needed.

## Important limitations
This workflow is a build configuration, not proof that the Android source compiles.
The first build may expose Kotlin/API/dependency errors that must be fixed before an APK
can be produced. No successful build or device test is claimed by this kit.
The current project is an experimental source project, not a production-verified app.
