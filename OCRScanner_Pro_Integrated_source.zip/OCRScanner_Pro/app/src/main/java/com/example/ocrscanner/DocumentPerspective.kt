package com.example.ocrscanner

import android.graphics.Bitmap
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max

/**
 * Detects the largest plausible four-corner document contour and rectifies its perspective.
 * Returns null if no reliable quadrilateral is found; callers should retain the original image.
 */
object DocumentPerspective {
    data class Detection(val bitmap: Bitmap, val corners: List<Point>)

    fun detectAndRectify(source: Bitmap): Detection? {
        if (!OpenCVLoader.initLocal()) return null
        val rgba = Mat()
        val gray = Mat()
        val blurred = Mat()
        val edges = Mat()
        val hierarchy = Mat()
        val contours = mutableListOf<MatOfPoint>()
        return try {
            Utils.bitmapToMat(source, rgba)
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.GaussianBlur(gray, blurred, Size(5.0, 5.0), 0.0)
            Imgproc.Canny(blurred, edges, 60.0, 180.0)
            Imgproc.findContours(edges, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE)
            val candidates = contours.sortedByDescending { Imgproc.contourArea(it) }
            var corners: MatOfPoint2f? = null
            for (contour in candidates.take(20)) {
                val curve = MatOfPoint2f(*contour.toArray())
                val approx = MatOfPoint2f()
                val perimeter = Imgproc.arcLength(curve, true)
                Imgproc.approxPolyDP(curve, approx, 0.02 * perimeter, true)
                if (approx.total() == 4L && Imgproc.contourArea(MatOfPoint(*approx.toArray())) >
                    source.width.toDouble() * source.height * 0.12) {
                    corners = approx
                    break
                }
                curve.release()
                approx.release()
            }
            val found = corners ?: return null
            val ordered = orderCorners(found.toArray().toList())
            val widthA = distance(ordered[2], ordered[3])
            val widthB = distance(ordered[1], ordered[0])
            val heightA = distance(ordered[1], ordered[2])
            val heightB = distance(ordered[0], ordered[3])
            val outW = max(1, max(widthA, widthB).toInt())
            val outH = max(1, max(heightA, heightB).toInt())
            val srcPts = MatOfPoint2f(*ordered.toTypedArray())
            val dstPts = MatOfPoint2f(
                Point(0.0, 0.0), Point((outW - 1).toDouble(), 0.0),
                Point((outW - 1).toDouble(), (outH - 1).toDouble()), Point(0.0, (outH - 1).toDouble())
            )
            val transform = Imgproc.getPerspectiveTransform(srcPts, dstPts)
            val warped = Mat()
            Imgproc.warpPerspective(rgba, warped, transform, Size(outW.toDouble(), outH.toDouble()))
            val output = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(warped, output)
            srcPts.release(); dstPts.release(); transform.release(); warped.release()
            Detection(output, ordered)
        } catch (_: Exception) {
            null
        } finally {
            rgba.release(); gray.release(); blurred.release(); edges.release(); hierarchy.release()
            contours.forEach { it.release() }
        }
    }

    private fun orderCorners(points: List<Point>): List<Point> {
        val sum = points.map { it.x + it.y }
        val diff = points.map { it.x - it.y }
        return listOf(
            points[sum.indices.minBy { sum[it] }],
            points[diff.indices.maxBy { diff[it] }],
            points[sum.indices.maxBy { sum[it] }],
            points[diff.indices.minBy { diff[it] }]
        )
    }
    private fun distance(a: Point, b: Point): Double =
        kotlin.math.hypot(a.x - b.x, a.y - b.y)
}
