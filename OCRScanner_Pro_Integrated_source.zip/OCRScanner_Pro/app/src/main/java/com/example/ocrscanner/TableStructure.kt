package com.example.ocrscanner

import android.graphics.Rect
import com.google.mlkit.vision.text.Text
import kotlin.math.abs
import kotlin.math.max

/**
 * Heuristic table reconstruction from OCR line bounding boxes.
 * It estimates columns from repeated x-centres and exports a tab-delimited representation.
 * Complex merged cells, borderless tables and multi-page tables need a dedicated layout model.
 */
object TableStructure {
    data class Cell(val row: Int, val column: Int, val text: String, val bounds: Rect)
    data class Table(val rows: List<List<Cell>>) {
        fun toTsv(): String = rows.joinToString("\n") { row ->
            row.joinToString("\t") { it.text.replace("\t", " ").replace("\n", " ") }
        }
    }

    fun reconstruct(result: Text, xTolerancePx: Int = 32, rowTolerancePx: Int = 18): Table {
        val lines = result.textBlocks.flatMap { block -> block.lines.mapNotNull { line ->
            val bounds = line.boundingBox
            if (bounds == null || line.text.isBlank()) null else Cell(-1, -1, line.text.trim(), Rect(bounds))
        }}.sortedWith(compareBy<Cell> { it.bounds.centerY() }.thenBy { it.bounds.left })

        val rowGroups = mutableListOf<MutableList<Cell>>()
        for (cell in lines) {
            val row = rowGroups.firstOrNull { group ->
                abs(group.map { it.bounds.centerY() }.average().toInt() - cell.bounds.centerY()) <= rowTolerancePx
            }
            if (row == null) rowGroups.add(mutableListOf(cell)) else row.add(cell)
        }
        val allCenters = lines.map { it.bounds.centerX() }.sorted()
        val centers = mutableListOf<Int>()
        allCenters.forEach { x ->
            if (centers.none { abs(it - x) <= xTolerancePx }) centers.add(x)
        }
        centers.sort()
        val rows = rowGroups.mapIndexed { rowIndex, group ->
            val sorted = group.sortedBy { it.bounds.left }
            sorted.mapIndexed { _, cell ->
                val col = centers.indices.minByOrNull { abs(centers[it] - cell.bounds.centerX()) } ?: 0
                cell.copy(row = rowIndex, column = col)
            }.sortedBy { it.column }
        }
        return Table(rows)
    }
}
