package com.example.ocrscanner

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import com.google.mlkit.vision.digitalink.recognition.Ink

/**
 * Touch/stylus handwriting pad. Captures vector strokes with coordinates and timestamps
 * for ML Kit Digital Ink Recognition. This is intentionally distinct from photo OCR.
 */
class HandwritingPadView(context: Context) : View(context) {
    private data class InkPointData(val x: Float, val y: Float, val time: Long)
    private val completedStrokes = mutableListOf<List<InkPointData>>()
    private var activeStroke = mutableListOf<InkPointData>()
    private val activePath = Path()
    private val paths = mutableListOf<Path>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF17233B.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 5f * resources.displayMetrics.density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0xFFFFFFFF.toInt())
        paths.forEach { canvas.drawPath(it, paint) }
        canvas.drawPath(activePath, paint)
        val guide = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFE3E8F0.toInt()
            strokeWidth = resources.displayMetrics.density
        }
        canvas.drawLine(0f, height - 18f, width.toFloat(), height - 18f, guide)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val now = System.currentTimeMillis()
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activeStroke = mutableListOf(InkPointData(event.x, event.y, now))
                activePath.moveTo(event.x, event.y)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.historySize) {
                    val x = event.getHistoricalX(i)
                    val y = event.getHistoricalY(i)
                    activeStroke.add(InkPointData(x, y, now - (event.historySize - i)))
                    activePath.lineTo(x, y)
                }
                activeStroke.add(InkPointData(event.x, event.y, now))
                activePath.lineTo(event.x, event.y)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                activeStroke.add(InkPointData(event.x, event.y, now))
                activePath.lineTo(event.x, event.y)
                completedStrokes.add(activeStroke.toList())
                paths.add(Path(activePath))
                activePath.reset()
                activeStroke.clear()
                invalidate()
                performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                activePath.reset()
                activeStroke.clear()
                invalidate()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    fun clearInk() {
        completedStrokes.clear()
        activeStroke.clear()
        paths.clear()
        activePath.reset()
        invalidate()
    }

    fun hasInk(): Boolean = completedStrokes.any { it.isNotEmpty() }

    fun buildInk(): Ink {
        val builder = Ink.builder()
        completedStrokes.forEach { strokePoints ->
            if (strokePoints.isNotEmpty()) {
                val strokeBuilder = Ink.Stroke.builder()
                strokePoints.forEach { point ->
                    strokeBuilder.addPoint(Ink.Point.create(point.x, point.y, point.time))
                }
                builder.addStroke(strokeBuilder.build())
            }
        }
        return builder.build()
    }
}
