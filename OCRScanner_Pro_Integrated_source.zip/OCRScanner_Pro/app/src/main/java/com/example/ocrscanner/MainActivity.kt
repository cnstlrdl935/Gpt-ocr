package com.example.ocrscanner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.widget.FrameLayout
import android.graphics.RectF
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognition
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModel
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognitionModelIdentifier
import com.google.mlkit.vision.digitalink.recognition.DigitalInkRecognizerOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * OCR Scanner Pro
 * - Camera, multiple images and PDF import through Android document providers (including Samsung My Files)
 * - Korean + Latin OCR, geometry-based line merge, rotation controls
 * - Batch processing, editable text, TXT/PDF export and Android share sheet
 *
 * Perspective correction, region OCR, table TSV export, searchable-image PDF export and local library
 * are connected as best-effort on-device features. Table layout and contour detection remain heuristic.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var resultText: EditText
    private lateinit var statusText: TextView
    private lateinit var preview: ImageView
    private lateinit var progress: ProgressBar
    private var cameraUri: Uri? = null
    private var currentBitmap: Bitmap? = null
    private var lastOcrResult: Text? = null
    private var regionOverlay: RegionSelectionView? = null
    private var rotationDegrees = 0f
    private var batchItems = mutableListOf<Pair<String, String>>()
    private var batchIndex = 0
    private var combinedOutput = StringBuilder()

    private val singleImagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { startImageOcr(it, true) }
    }
    private val multiImagePicker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (!uris.isNullOrEmpty()) startBatch(uris)
    }
    private val anyDocumentPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            val type = contentResolver.getType(it).orEmpty()
            if (type == "application/pdf" || it.toString().lowercase().endsWith(".pdf")) {
                processPdf(it)
            } else startImageOcr(it, true)
        }
    }
    private val cameraCapture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) cameraUri?.let { startImageOcr(it, true) }
        else statusText.text = "촬영이 취소되었습니다."
    }
    private val txtCreator = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) writeText(uri, resultText.text.toString(), "TXT")
    }
    private val pdfCreator = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) writePdf(uri, resultText.text.toString())
    }
    private val searchablePdfCreator = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val bitmap = currentBitmap
        val ocr = lastOcrResult
        if (uri != null && bitmap != null && ocr != null) {
            try {
                SearchablePdfExporter.write(contentResolver, uri, bitmap, ocr)
                toast("원본 이미지와 검색 가능한 OCR 텍스트를 PDF로 저장했습니다.")
            } catch (e: Exception) {
                toast("검색 가능한 PDF 저장 실패: ${e.localizedMessage}")
            }
        } else if (uri != null) toast("먼저 이미지 문서를 인식해 주세요.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(0xFFF5F7FB.toInt()) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("OCR 스캐너 Pro", 27f, true, 0xFF17233B.toInt()))
        page.addView(label("한국어 · 영어 · 다중 이미지 · PDF · 삼성 내 파일 연동", 13f, false, 0xFF667085.toInt()))
        val row1 = horizontal()
        row1.addView(button("카메라 촬영") { launchCamera() }, weighted())
        row1.addView(button("사진 한 장") { singleImagePicker.launch("image/*") }, weighted())
        page.addView(row1)
        val row2 = horizontal()
        row2.addView(button("여러 사진") { multiImagePicker.launch(arrayOf("image/*")) }, weighted())
        row2.addView(button("사진/PDF 불러오기") { anyDocumentPicker.launch(arrayOf("image/*", "application/pdf")) }, weighted())
        page.addView(row2)

        preview = ImageView(this).apply {
            visibility = View.GONE
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFFE8ECF4.toInt())
        }
        val previewFrame = FrameLayout(this)
        previewFrame.addView(preview, FrameLayout.LayoutParams(-1, dp(240)))
        regionOverlay = RegionSelectionView(this).apply {
            visibility = View.GONE
            onRegionSelected = { rect -> runRegionOcr(rect) }
        }
        previewFrame.addView(regionOverlay, FrameLayout.LayoutParams(-1, dp(240)))
        page.addView(previewFrame, LinearLayout.LayoutParams(-1, dp(240)).apply { topMargin = dp(12) })
        val rotateRow = horizontal()
        rotateRow.addView(button("왼쪽 90°") { rotatePreview(-90f) }, weighted())
        rotateRow.addView(button("오른쪽 90°") { rotatePreview(90f) }, weighted())
        page.addView(rotateRow)
        val toolsRow = horizontal()
        toolsRow.addView(button("문서 자동 보정") { rectifyCurrentDocument() }, weighted())
        toolsRow.addView(button("영역 지정 OCR") { enableRegionSelection() }, weighted())
        page.addView(toolsRow)
        page.addView(button("현재 이미지로 다시 OCR") { rerunCurrentImageOcr() }, LinearLayout.LayoutParams(-1, dp(44)))
        val exportTools = horizontal()
        exportTools.addView(button("검색 가능한 이미지 PDF") { saveSearchablePdf() }, weighted())
        exportTools.addView(button("표를 TSV로 복사") { copyTableTsv() }, weighted())
        page.addView(exportTools)
        page.addView(button("손글씨 직접 쓰고 인식") { showHandwritingPad() }, LinearLayout.LayoutParams(-1, dp(44)))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
            isIndeterminate = true
        }
        page.addView(progress, LinearLayout.LayoutParams(-1, dp(5)))
        statusText = label("이미지를 촬영하거나 파일을 불러오세요.", 13f, false, 0xFF667085.toInt())
        page.addView(statusText)

        page.addView(label("인식 결과 (직접 수정 가능)", 17f, true, 0xFF17233B.toInt()))
        resultText = EditText(this).apply {
            hint = "인식된 텍스트가 여기에 표시됩니다."
            gravity = Gravity.TOP or Gravity.START
            minLines = 10
            setTextSize(15f)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        page.addView(resultText, LinearLayout.LayoutParams(-1, dp(280)))

        val row3 = horizontal()
        row3.addView(button("복사") { copyText() }, weighted())
        row3.addView(button("공유") { shareText() }, weighted())
        page.addView(row3)
        val row4 = horizontal()
        row4.addView(button("TXT로 내 파일에 저장") { saveTxt() }, weighted())
        row4.addView(button("PDF로 내 파일에 저장") { savePdf() }, weighted())
        page.addView(row4)
        val libraryRow = horizontal()
        libraryRow.addView(button("문서 이력") { showLibrary(false) }, weighted())
        libraryRow.addView(button("즐겨찾기") { showLibrary(true) }, weighted())
        page.addView(libraryRow)
        page.addView(button("현재 결과를 이력에 저장") {
            val value = resultText.text.toString()
            if (value.isBlank()) toast("저장할 결과가 없습니다.")
            else {
                DocumentLibrary(this).add("OCR_${timestamp()}", value)
                toast("문서 이력에 저장했습니다.")
            }
        }, LinearLayout.LayoutParams(-1, dp(46)))
        page.addView(button("결과 지우기") {
            resultText.setText("")
            batchItems.clear()
            combinedOutput.clear()
            statusText.text = "결과를 지웠습니다."
        }, LinearLayout.LayoutParams(-1, dp(46)))
        page.addView(label(
            "파일 접근 안내: '사진/PDF 불러오기'와 저장 버튼은 Android 파일 선택 화면을 엽니다. 삼성 기기에서는 '내 파일'을 선택할 수 있습니다.",
            12f, false, 0xFF667085.toInt()
        ))
    }

    private fun label(textValue: String, size: Float, bold: Boolean, color: Int) =
        TextView(this).apply {
            text = textValue
            textSize = size
            setTextColor(color)
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(7), 0, dp(7))
        }

    private fun horizontal() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun weighted() = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
        marginEnd = dp(5)
    }

    private fun button(title: String, action: () -> Unit) =
        Button(this).apply {
            text = title
            isAllCaps = false
            textSize = 12f
            setOnClickListener { action() }
        }

    private fun launchCamera() {
        try {
            val dir = File(cacheDir, "camera").apply { mkdirs() }
            val file = File(dir, "ocr_${System.currentTimeMillis()}.jpg")
            cameraUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            cameraCapture.launch(cameraUri!!)
        } catch (e: Exception) {
            statusText.text = "카메라를 열 수 없습니다: ${e.localizedMessage}"
        }
    }

    private fun startImageOcr(uri: Uri, showImage: Boolean) {
        progress.visibility = View.VISIBLE
        statusText.text = "이미지를 분석하고 있습니다..."
        if (showImage) {
            try {
                currentBitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                currentBitmap?.let {
                    rotationDegrees = 0f
                    preview.setImageBitmap(it)
                    preview.visibility = View.VISIBLE
                }
            } catch (_: Exception) { /* OCR may still work directly from Uri */ }
        }
        try {
            Thread {
                try {
                    val sourceBitmap = currentBitmap
                    val corrected = sourceBitmap?.let { DocumentPerspective.detectAndRectify(it) }
                    val bitmapForOcr = corrected?.bitmap ?: sourceBitmap
                    val image = if (bitmapForOcr != null) InputImage.fromBitmap(bitmapForOcr, 0)
                        else InputImage.fromFilePath(this, uri)
                    runOnUiThread {
                        if (corrected != null) {
                            currentBitmap = corrected.bitmap
                            preview.setImageBitmap(corrected.bitmap)
                            preview.visibility = View.VISIBLE
                        }
                        statusText.text = "한국어와 영어 문자를 분석하고 있습니다..."
                    }
                    runBothRecognizers(image) { text, error, ocrResult ->
                        progress.visibility = View.GONE
                        if (error != null) statusText.text = "인식 중 오류: $error"
                        else {
                            lastOcrResult = ocrResult
                            resultText.setText(text)
                            if (text.isNotBlank()) DocumentLibrary(this).add("OCR_${timestamp()}", text)
                            statusText.text = if (text.isBlank()) "문자를 찾지 못했습니다. 선명한 이미지로 다시 시도해 주세요."
                            else "인식 완료 · ${text.length}자"
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        progress.visibility = View.GONE
                        statusText.text = "파일을 읽을 수 없습니다: ${e.localizedMessage}"
                    }
                }
            }.start()
        } catch (e: Exception) {
            progress.visibility = View.GONE
            statusText.text = "파일을 읽을 수 없습니다: ${e.localizedMessage}"
        }
    }

    private fun runBothRecognizers(image: InputImage, done: (String, String?, Text?) -> Unit) {
        val latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val korean = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        var latinResult: Text? = null
        var koreanResult: Text? = null
        var latinError: Exception? = null
        var koreanError: Exception? = null
        fun finishIfReady() {
            if (latinResult == null && latinError == null) return
            if (koreanResult == null && koreanError == null) return
            val merged = mergeGeometricLines(latinResult, koreanResult)
            latin.close()
            korean.close()
            done(merged, if (merged.isBlank() && latinError != null && koreanError != null)
                "${latinError?.localizedMessage}; ${koreanError?.localizedMessage}" else null,
                listOfNotNull(koreanResult, latinResult).maxByOrNull { it.text.length })
        }
        latin.process(image)
            .addOnSuccessListener { latinResult = it; finishIfReady() }
            .addOnFailureListener { latinError = it; finishIfReady() }
        korean.process(image)
            .addOnSuccessListener { koreanResult = it; finishIfReady() }
            .addOnFailureListener { koreanError = it; finishIfReady() }
    }

    private data class LineCandidate(val text: String, val box: Rect, val fromKorean: Boolean)

    /**
     * Merge recognizer lines by geometry rather than discarding an entire language pass.
     * Overlapping duplicates are resolved by preferring the line containing Hangul.
     * The resulting order is top-to-bottom, then left-to-right.
     */
    private fun mergeGeometricLines(latin: Text?, korean: Text?): String {
        val candidates = mutableListOf<LineCandidate>()
        fun add(result: Text?, isKorean: Boolean) {
            result?.textBlocks?.forEach { block ->
                block.lines.forEach { line ->
                    val box = line.boundingBox ?: Rect(0, 0, 0, 0)
                    if (line.text.isNotBlank()) candidates.add(LineCandidate(line.text.trim(), Rect(box), isKorean))
                }
            }
        }
        add(latin, false)
        add(korean, true)
        val unique = mutableListOf<LineCandidate>()
        candidates.sortedByDescending { it.fromKorean }.forEach { candidate ->
            val duplicateIndex = unique.indexOfFirst { existing ->
                overlapRatio(candidate.box, existing.box) > 0.45f ||
                    normalize(candidate.text) == normalize(existing.text)
            }
            if (duplicateIndex < 0) unique.add(candidate)
            else {
                val old = unique[duplicateIndex]
                if (candidate.text.any { it in '\uAC00'..'\uD7A3' } &&
                    !old.text.any { it in '\uAC00'..'\uD7A3' }) unique[duplicateIndex] = candidate
            }
        }
        unique.sortWith(compareBy<LineCandidate> { it.box.centerY() }
            .thenBy { it.box.left })
        // Keep nearby lines grouped into paragraphs; preserve rough columns with spacing.
        return unique.joinToString("\n") { it.text }
    }

    private fun overlapRatio(a: Rect, b: Rect): Float {
        val intersection = Rect()
        if (!intersection.setIntersect(a, b)) return 0f
        val smaller = min(a.width() * a.height(), b.width() * b.height()).coerceAtLeast(1)
        return intersection.width().toFloat() * intersection.height() / smaller
    }

    private fun normalize(value: String) = value.lowercase(Locale.ROOT).replace(Regex("\\s+"), "")
        .replace(Regex("[^\\p{L}\\p{N}]"), "")

    private fun rotatePreview(degrees: Float) {
        val bitmap = currentBitmap ?: run { toast("먼저 이미지를 불러오세요."); return }
        rotationDegrees = (rotationDegrees + degrees + 360f) % 360f
        val matrix = Matrix().apply { postRotate(degrees) }
        currentBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        preview.setImageBitmap(currentBitmap)
        statusText.text = "미리보기 회전 완료. 원본 파일을 다시 인식하려면 사진을 다시 불러오세요."
    }

    private fun startBatch(uris: List<Uri>) {
        batchItems.clear()
        combinedOutput = StringBuilder()
        batchIndex = 0
        progress.visibility = View.VISIBLE
        processNextBatch(uris)
    }

    private fun processNextBatch(uris: List<Uri>) {
        if (batchIndex >= uris.size) {
            progress.visibility = View.GONE
            resultText.setText(combinedOutput.toString().trim())
            if (combinedOutput.isNotBlank()) DocumentLibrary(this).add("일괄_OCR_${timestamp()}", combinedOutput.toString())
            statusText.text = "일괄 인식 완료 · ${uris.size}개 파일"
            return
        }
        val uri = uris[batchIndex]
        statusText.text = "일괄 인식 ${batchIndex + 1}/${uris.size}"
        try {
            val image = InputImage.fromFilePath(this, uri)
            runBothRecognizers(image) { text, error, _ ->
                if (error == null && text.isNotBlank()) {
                    val name = queryDisplayName(uri) ?: "이미지 ${batchIndex + 1}"
                    batchItems.add(name to text)
                    combinedOutput.append("\n\n===== $name =====\n").append(text)
                } else if (error != null) {
                    combinedOutput.append("\n\n===== 파일 ${batchIndex + 1}: 오류 =====\n$error")
                }
                batchIndex++
                processNextBatch(uris)
            }
        } catch (e: Exception) {
            combinedOutput.append("\n\n===== 파일 ${batchIndex + 1}: 오류 =====\n${e.localizedMessage}")
            batchIndex++
            processNextBatch(uris)
        }
    }

    private fun processPdf(uri: Uri) {
        progress.visibility = View.VISIBLE
        statusText.text = "PDF 페이지를 분석하고 있습니다..."
        Thread {
            val output = StringBuilder()
            try {
                val pfd = contentResolver.openFileDescriptor(uri, "r")
                    ?: throw IllegalStateException("PDF 파일을 열 수 없습니다.")
                pfd.use { descriptor ->
                    PdfRenderer(descriptor).use { renderer ->
                        for (pageNumber in 0 until renderer.pageCount) {
                            val page = renderer.openPage(pageNumber)
                            val scale = min(2.0f, 1800f / max(page.width, page.height))
                            val bitmap = Bitmap.createBitmap(
                                max(1, (page.width * scale).toInt()),
                                max(1, (page.height * scale).toInt()),
                                Bitmap.Config.ARGB_8888
                            )
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            page.close()
                            val latch = java.util.concurrent.CountDownLatch(1)
                            var pageText = ""
                            var pageError: String? = null
                            runOnUiThread {
                                runBothRecognizers(InputImage.fromBitmap(bitmap, 0)) { text, error, _ ->
                                    pageText = text
                                    pageError = error
                                    latch.countDown()
                                }
                            }
                            latch.await()
                            output.append("\n\n===== PDF ${pageNumber + 1}페이지 =====\n")
                                .append(pageText.ifBlank { pageError ?: "인식된 문자가 없습니다." })
                            bitmap.recycle()
                        }
                    }
                }
                runOnUiThread {
                    progress.visibility = View.GONE
                    val finalText = output.toString().trim()
                    resultText.setText(finalText)
                    if (finalText.isNotBlank()) DocumentLibrary(this).add("PDF_OCR_${timestamp()}", finalText)
                    lastOcrResult = null
                    statusText.text = "PDF 인식 완료 · ${rendererPageCountLabel(finalText)}"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    statusText.text = "PDF 처리 실패: ${e.localizedMessage}"
                }
            }
        }.start()
    }

    private fun rerunCurrentImageOcr() {
        val bitmap = currentBitmap ?: run { toast("먼저 이미지를 불러오세요."); return }
        progress.visibility = View.VISIBLE
        statusText.text = "현재 이미지에서 OCR을 다시 실행하고 있습니다..."
        runBothRecognizers(InputImage.fromBitmap(bitmap, 0)) { text, error, ocr ->
            progress.visibility = View.GONE
            if (error != null) statusText.text = "인식 실패: $error"
            else {
                lastOcrResult = ocr
                resultText.setText(text)
                if (text.isNotBlank()) DocumentLibrary(this).add("OCR_${timestamp()}", text)
                statusText.text = "재인식 완료 · ${text.length}자"
            }
        }
    }

    private fun rectifyCurrentDocument() {
        val source = currentBitmap ?: run { toast("먼저 이미지를 불러오세요."); return }
        progress.visibility = View.VISIBLE
        statusText.text = "문서 테두리와 원근을 분석하고 있습니다..."
        Thread {
            val detection = DocumentPerspective.detectAndRectify(source)
            runOnUiThread {
                progress.visibility = View.GONE
                if (detection == null) {
                    statusText.text = "문서의 네 모서리를 안정적으로 찾지 못했습니다. 원본 이미지를 유지합니다."
                } else {
                    currentBitmap = detection.bitmap
                    preview.setImageBitmap(detection.bitmap)
                    statusText.text = "문서 원근 보정 완료. 보정된 이미지로 다시 OCR을 실행해 주세요."
                }
            }
        }.start()
    }

    private fun enableRegionSelection() {
        if (currentBitmap == null) { toast("먼저 이미지를 불러오세요."); return }
        regionOverlay?.visibility = View.VISIBLE
        statusText.text = "미리보기에서 인식할 영역을 손가락으로 드래그해 지정하세요."
    }

    private fun runRegionOcr(viewRect: RectF) {
        val bitmap = currentBitmap ?: return
        val viewWidth = (regionOverlay?.width ?: 0).toFloat().coerceAtLeast(1f)
        val viewHeight = (regionOverlay?.height ?: 0).toFloat().coerceAtLeast(1f)
        val scale = min(viewWidth / bitmap.width, viewHeight / bitmap.height)
        val shownWidth = bitmap.width * scale
        val shownHeight = bitmap.height * scale
        val offsetX = (viewWidth - shownWidth) / 2f
        val offsetY = (viewHeight - shownHeight) / 2f
        val left = (((viewRect.left - offsetX) / scale).toInt()).coerceIn(0, bitmap.width - 1)
        val top = (((viewRect.top - offsetY) / scale).toInt()).coerceIn(0, bitmap.height - 1)
        val right = (((viewRect.right - offsetX) / scale).toInt()).coerceIn(left + 1, bitmap.width)
        val bottom = (((viewRect.bottom - offsetY) / scale).toInt()).coerceIn(top + 1, bitmap.height)
        val crop = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
        regionOverlay?.visibility = View.GONE
        progress.visibility = View.VISIBLE
        statusText.text = "선택한 영역을 인식하고 있습니다..."
        runBothRecognizers(InputImage.fromBitmap(crop, 0)) { text, error, ocr ->
            progress.visibility = View.GONE
            crop.recycle()
            if (error != null) statusText.text = "영역 OCR 실패: $error"
            else {
                lastOcrResult = ocr
                resultText.setText(text)
                if (text.isNotBlank()) DocumentLibrary(this).add("영역_OCR_${timestamp()}", text)
                statusText.text = "영역 OCR 완료 · ${text.length}자"
            }
        }
    }

    private fun saveSearchablePdf() {
        if (currentBitmap == null || lastOcrResult == null) {
            toast("이미지를 불러와 OCR을 먼저 실행해 주세요.")
            return
        }
        searchablePdfCreator.launch("ocr_searchable_${timestamp()}.pdf")
    }

    private fun copyTableTsv() {
        val ocr = lastOcrResult ?: run { toast("먼저 OCR을 실행해 주세요."); return }
        val tsv = TableStructure.reconstruct(ocr).toTsv()
        if (tsv.isBlank()) { toast("표로 변환할 문자가 없습니다."); return }
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("OCR table TSV", tsv))
        toast("표 구조 추정 결과를 TSV 형식으로 복사했습니다. 정확한 셀 병합은 보장되지 않습니다.")
    }

    private fun showHandwritingPad() {
        val pad = HandwritingPadView(this)
        val languagePicker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("한국어 손글씨", "영어 손글씨"))
        }
        val note = label("화면에 손가락이나 펜으로 글씨를 써 주세요. 최초 사용 시 언어 모델을 내려받습니다.",
            12f, false, 0xFF667085.toInt())
        val clearButton = button("필기 지우기") { pad.clearInk() }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
            addView(languagePicker)
            addView(note)
            addView(pad, LinearLayout.LayoutParams(-1, dp(220)))
            addView(clearButton, LinearLayout.LayoutParams(-1, dp(44)))
        }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("손글씨 인식")
            .setView(content)
            .setPositiveButton("인식", null)
            .setNegativeButton("닫기", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (!pad.hasInk()) {
                    toast("먼저 필기 영역에 글씨를 써 주세요.")
                    return@setOnClickListener
                }
                val languageTag = if (languagePicker.selectedItemPosition == 0) "ko-KR" else "en-US"
                val identifier = try {
                    DigitalInkRecognitionModelIdentifier.fromLanguageTag(languageTag)
                } catch (e: Exception) {
                    toast("선택한 언어의 손글씨 모델을 찾지 못했습니다: ${e.localizedMessage}")
                    return@setOnClickListener
                }
                if (identifier == null) {
                    toast("선택한 언어의 손글씨 인식 모델을 사용할 수 없습니다.")
                    return@setOnClickListener
                }
                val model = DigitalInkRecognitionModel.builder(identifier).build()
                val ink = pad.buildInk()
                note.text = "손글씨 모델을 확인하고 있습니다. 네트워크 상태에 따라 시간이 걸릴 수 있습니다..."
                dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).isEnabled = false

                fun recognizeInk() {
                    val recognizer = DigitalInkRecognition.getClient(
                        DigitalInkRecognizerOptions.builder(model).build())
                    recognizer.recognize(ink)
                        .addOnSuccessListener { result ->
                            val recognized = result.candidates.firstOrNull()?.text.orEmpty()
                            if (recognized.isNotBlank()) {
                                resultText.setText(recognized)
                                DocumentLibrary(this).add("손글씨_${timestamp()}", recognized)
                                statusText.text = "손글씨 인식 완료 · ${recognized.length}자"
                                dialog.dismiss()
                            } else {
                                note.text = "인식 결과가 없습니다. 글씨를 조금 더 크게 쓰고 다시 시도해 주세요."
                                dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).isEnabled = true
                            }
                            recognizer.close()
                        }
                        .addOnFailureListener { error ->
                            note.text = "손글씨 인식 실패: ${error.localizedMessage}"
                            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).isEnabled = true
                            recognizer.close()
                        }
                }

                RemoteModelManager.getInstance().isModelDownloaded(model)
                    .addOnSuccessListener { downloaded ->
                        if (downloaded) recognizeInk()
                        else RemoteModelManager.getInstance()
                            .download(model, DownloadConditions.Builder().build())
                            .addOnSuccessListener { recognizeInk() }
                            .addOnFailureListener { error ->
                                note.text = "손글씨 모델 다운로드 실패: ${error.localizedMessage}"
                                dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).isEnabled = true
                            }
                    }
                    .addOnFailureListener { error ->
                        note.text = "모델 상태 확인 실패: ${error.localizedMessage}"
                        dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).isEnabled = true
                    }
            }
        }
        dialog.show()
    }

    private fun rendererPageCountLabel(value: String): String =
        "${Regex("===== PDF \\d+페이지 =====").findAll(value).count()}페이지"

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: Exception) { null }
    }

    private fun showLibrary(onlyFavorites: Boolean) {
        val library = DocumentLibrary(this)
        val entries = if (onlyFavorites) library.favorites() else library.all()
        val names = entries.map { (if (it.favorite) "★ " else "") + it.title + " · " + it.category }
        if (entries.isEmpty()) { toast("저장된 문서가 없습니다."); return }
        val input = EditText(this).apply { hint = "문서 검색어 입력 (비워두면 전체 표시)" }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
            addView(input)
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(if (onlyFavorites) "즐겨찾기" else "문서 이력")
            .setView(layout)
            .setItems(names.toTypedArray()) { _, which ->
                val selected = entries[which]
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle(selected.title)
                    .setItems(arrayOf("문서 불러오기", if (selected.favorite) "즐겨찾기 해제" else "즐겨찾기 추가", "문서 삭제")) { _, action ->
                        when (action) {
                            0 -> { resultText.setText(selected.text); statusText.text = "문서를 불러왔습니다." }
                            1 -> { library.toggleFavorite(selected.id); toast("즐겨찾기 상태를 변경했습니다.") }
                            2 -> { library.delete(selected.id); toast("문서를 삭제했습니다.") }
                        }
                    }.setNegativeButton("닫기", null).show()
            }
            .setPositiveButton("검색") { _, _ ->
                val query = input.text.toString()
                val found = library.search(query).let { if (onlyFavorites) it.filter { e -> e.favorite } else it }
                val foundNames = found.map { (if (it.favorite) "★ " else "") + it.title + " · " + it.category }
                if (found.isEmpty()) toast("검색 결과가 없습니다.")
                else androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("검색 결과")
                    .setItems(foundNames.toTypedArray()) { _, index -> resultText.setText(found[index].text) }
                    .setNegativeButton("닫기", null).show()
            }
            .setNegativeButton("닫기", null)
            .show()
    }

    private fun copyText() {
        val value = resultText.text.toString()
        if (value.isBlank()) { toast("복사할 텍스트가 없습니다."); return }
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("OCR text", value))
        toast("텍스트를 복사했습니다.")
    }

    private fun shareText() {
        val value = resultText.text.toString()
        if (value.isBlank()) { toast("공유할 텍스트가 없습니다."); return }
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, value)
        }, "인식 결과 공유"))
    }

    private fun saveTxt() {
        if (resultText.text.isBlank()) { toast("저장할 텍스트가 없습니다."); return }
        txtCreator.launch("ocr_${timestamp()}.txt")
    }

    private fun savePdf() {
        if (resultText.text.isBlank()) { toast("저장할 텍스트가 없습니다."); return }
        pdfCreator.launch("ocr_${timestamp()}.pdf")
    }

    private fun writeText(uri: Uri, value: String, label: String) {
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(value.toByteArray(Charsets.UTF_8)) }
            toast("$label 파일을 저장했습니다.")
        } catch (e: Exception) { toast("저장 실패: ${e.localizedMessage}") }
    }

    private fun writePdf(uri: Uri, value: String) {
        try {
            val document = PdfDocument()
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = android.graphics.Color.BLACK }
            val pageWidth = 595
            val pageHeight = 842
            val left = 42f
            val top = 48f
            val lineHeight = 16f
            val maxChars = 78
            val lines = mutableListOf<String>()
            value.lines().forEach { line ->
                if (line.isEmpty()) lines.add("")
                else line.chunked(maxChars).forEach { lines.add(it) }
            }
            val perPage = ((pageHeight - top - 42) / lineHeight).toInt()
            val chunks = lines.chunked(perPage).ifEmpty { listOf(listOf("")) }
            chunks.forEachIndexed { index, chunk ->
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                val page = document.startPage(pageInfo)
                chunk.forEachIndexed { lineIndex, line ->
                    page.canvas.drawText(line, left, top + (lineIndex + 1) * lineHeight, paint)
                }
                document.finishPage(page)
            }
            contentResolver.openOutputStream(uri)?.use { document.writeTo(it) }
            document.close()
            toast("PDF 파일을 저장했습니다.")
        } catch (e: Exception) { toast("PDF 저장 실패: ${e.localizedMessage}") }
    }

    private fun timestamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
