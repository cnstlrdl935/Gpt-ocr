package com.example.ocrscanner

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Lightweight local document history, favorites and full-text search.
 * Data remains in app-private SharedPreferences; no cloud upload is performed.
 */
class DocumentLibrary(context: Context) {
    data class Entry(
        val id: String, val title: String, val text: String,
        val category: String, val createdAt: Long, val favorite: Boolean
    )
    private val prefs = context.getSharedPreferences("ocr_document_library", Context.MODE_PRIVATE)
    private val key = "entries"

    @Synchronized fun all(): List<Entry> = decode()
    @Synchronized fun add(title: String, text: String): Entry {
        val entry = Entry(UUID.randomUUID().toString(), title, text, classify(title, text),
            System.currentTimeMillis(), false)
        val items = decode().toMutableList()
        items.add(0, entry)
        save(items.take(500))
        return entry
    }
    @Synchronized fun toggleFavorite(id: String) {
        save(decode().map { if (it.id == id) it.copy(favorite = !it.favorite) else it })
    }
    @Synchronized fun favorites(): List<Entry> = decode().filter { it.favorite }
    @Synchronized fun search(query: String): List<Entry> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return decode()
        return decode().filter {
            it.title.lowercase().contains(q) || it.text.lowercase().contains(q) ||
                it.category.lowercase().contains(q)
        }
    }
    @Synchronized fun delete(id: String) { save(decode().filterNot { it.id == id }) }
    private fun classify(title: String, text: String): String {
        val sample = (title + " " + text.take(3000)).lowercase()
        return when {
            listOf("invoice", "total", "tax", "공급자", "합계", "세금계산서").any { sample.contains(it) } -> "영수증·청구서"
            listOf("contract", "agreement", "계약", "서명").any { sample.contains(it) } -> "계약서"
            listOf("resume", "curriculum", "이력서", "경력").any { sample.contains(it) } -> "이력서"
            listOf("lecture", "chapter", "강의", "수업", "과목").any { sample.contains(it) } -> "학습자료"
            else -> "일반 문서"
        }
    }
    private fun decode(): List<Entry> = try {
        val array = JSONArray(prefs.getString(key, "[]"))
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Entry(o.getString("id"), o.getString("title"), o.getString("text"),
                o.optString("category", "일반 문서"), o.optLong("createdAt"), o.optBoolean("favorite"))
        }
    } catch (_: Exception) { emptyList() }
    private fun save(entries: List<Entry>) {
        val array = JSONArray()
        entries.forEach { e ->
            array.put(JSONObject().put("id", e.id).put("title", e.title).put("text", e.text)
                .put("category", e.category).put("createdAt", e.createdAt).put("favorite", e.favorite))
        }
        prefs.edit().putString(key, array.toString()).apply()
    }
}
