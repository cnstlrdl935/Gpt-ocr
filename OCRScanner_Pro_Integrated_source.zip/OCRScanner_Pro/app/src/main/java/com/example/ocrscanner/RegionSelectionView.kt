package com.example.ocrscanner

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Transparent drag-to-select OCR region overlay.
 * Attach above an image preview; selectedRect is in this View's local pixel coordinates.
 */
class RegionSelectionView(context: Context) : View(context) {
    var selectedRect: RectF? = null
        private set
    var onRegionSelected: ((RectF) -> Unit)? = null
    private var startX = 0f
    private var startY = 0f
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55000000 }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF18A66A.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x2218A66A }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val rect = selectedRect ?: return
        canvas.drawRect(rect, fill)
        canvas.drawRect(rect, stroke)
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x; startY = event.y
                selectedRect = RectF(startX, startY, startX, startY)
                invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> {
                selectedRect = RectF(
                    minOf(startX, event.x), minOf(startY, event.y),
                    maxOf(startX, event.x), maxOf(startY, event.y)
                )
                invalidate(); return true
            }
            MotionEvent.ACTION_UP -> {
                selectedRect?.let { if (it.width() > 12 && it.height() > 12) onRegionSelected?.invoke(RectF(it)) }
                performClick(); return true
            }
        }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
