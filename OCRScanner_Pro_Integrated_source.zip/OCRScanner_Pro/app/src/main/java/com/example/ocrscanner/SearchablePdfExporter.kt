package com.example.ocrscanner

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.google.mlkit.vision.text.Text
import java.io.IOException
import kotlin.math.max
import kotlin.math.min

/**
 * Single-page image-based searchable PDF.
 *
 * The original image is drawn as the visible page. OCR text is added as a nearly-transparent
 * text layer at detected line positions. For each line, the foreground RGB is estimated by
 * sampling the darkest pixels inside its bounding box. This approximates original text color
 * (black, blue, red, etc.) while keeping the OCR layer visually unobtrusive.
 *
 * Important: sampling is heuristic. Anti-aliasing, colored backgrounds, photos, shadows,
 * low contrast and mixed-color text can produce imperfect color estimates. PDF viewer behavior
 * for transparent searchable text varies.
 */
object SearchablePdfExporter {
    fun write(
        resolver: ContentResolver,
        destination: Uri,
        bitmap: Bitmap,
        ocr: Text,
        transparency: Int = 2
    ) {
        val pdf = PdfDocument()
        val info = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
        val page = pdf.startPage(info)
        page.canvas.drawBitmap(bitmap, 0f, 0f, null)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12f
            alpha = transparency.coerceIn(1, 16)
        }

        ocr.textBlocks.forEach { block ->
            block.lines.forEach lineLoop@{ line ->
                val bounds: Rect = line.boundingBox ?: return@lineLoop
                if (line.text.isBlank()) return@lineLoop
                paint.color = estimateForegroundColor(bitmap, bounds)
                val targetHeight = max(1, bounds.height())
                paint.textSize = targetHeight.toFloat().coerceIn(8f, 96f)
                page.canvas.drawText(line.text, bounds.left.toFloat(), bounds.bottom.toFloat(), paint)
            }
        }

        pdf.finishPage(page)
        try {
            resolver.openOutputStream(destination)?.use { pdf.writeTo(it) }
                ?: throw IOException("출력 파일을 열 수 없습니다.")
        } finally {
            pdf.close()
        }
    }

    /**
     * Estimates the foreground ink color from pixels in the OCR line rectangle.
     * Uses a small grid and chooses a low-luminance sample, which is usually closer to ink
     * than the paper/background color. It preserves RGB chroma instead of forcing black.
     */
    private fun estimateForegroundColor(bitmap: Bitmap, input: Rect): Int {
        val left = input.left.coerceIn(0, bitmap.width - 1)
        val top = input.top.coerceIn(0, bitmap.height - 1)
        val right = input.right.coerceIn(left + 1, bitmap.width)
        val bottom = input.bottom.coerceIn(top + 1, bitmap.height)
        val width = right - left
        val height = bottom - top
        val stepX = max(1, width / 18)
        val stepY = max(1, height / 8)
        var best = android.graphics.Color.BLACK
        var bestScore = Double.MAX_VALUE

        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                val pixel = bitmap.getPixel(x, y)
                val r = android.graphics.Color.red(pixel)
                val g = android.graphics.Color.green(pixel)
                val b = android.graphics.Color.blue(pixel)
                val luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
                // Prefer darker ink but retain a small penalty for near-black neutral pixels
                // so saturated colored ink can win when its luminance is comparable.
                val chroma = max(r, max(g, b)) - min(r, min(g, b))
                val score = luminance - chroma * 0.12
                if (score < bestScore) {
                    bestScore = score
                    best = android.graphics.Color.rgb(r, g, b)
                }
                x += stepX
            }
            y += stepY
        }
        return best
    }
}
