# OCR Scanner Pro 3.0 — Android Studio project

이 저장소는 APK가 아니라 Android Studio에서 빌드하는 전체 소스 프로젝트입니다.

## 연결된 기능

- 한국어 및 영어 인쇄체 OCR: Google ML Kit 두 인식기를 실행하고 결과 줄의 위치를 기준으로 중복을 정리합니다.
- 카메라 촬영, 사진 한 장, 여러 사진 가져오기
- Android 문서 선택기(SAF)를 통한 이미지/PDF 열기 및 TXT/PDF 저장. 삼성 기기에서는 문서 선택 화면에서 삼성 내 파일을 선택할 수 있습니다.
- PDF 페이지 렌더링 후 페이지별 OCR
- OpenCV 기반 문서 사각형 검출 및 원근 보정: 이미지 불러오기 시 자동 시도하며 수동 보정 버튼도 제공합니다.
- OCR 영역 선택: 미리보기에서 드래그한 영역을 잘라 별도 OCR을 실행합니다.
- 표 구조 추정 및 TSV 복사: OCR 줄의 위치를 이용하는 휴리스틱입니다.
- 검색 가능한 이미지 기반 PDF: 현재 선택된 이미지 페이지를 배경으로 넣고 OCR 텍스트 레이어를 얹습니다. 텍스트 색상은 원본 픽셀에서 추정합니다.
- 손글씨 입력 패드: 화면에 직접 쓴 한국어/영어 획을 ML Kit Digital Ink Recognition으로 인식합니다. 최초 사용 시 언어별 모델을 내려받습니다.
- 문서 이력, 키워드 기반 분류, 전체 텍스트 검색, 즐겨찾기, 삭제
- 결과 수정, 복사, 공유, TXT 저장, 일반 텍스트 PDF 저장
- GitHub Actions 수동/푸시 빌드 워크플로

## 중요한 기능 범위

1. **손글씨 인식 범위:** 앱의 손글씨 패드에서 직접 쓴 획은 ML Kit Digital Ink Recognition으로 한국어/영어 인식이 연결되어 있습니다. 이는 획의 좌표·시간 정보를 쓰는 기능이며, 카메라로 촬영한 손글씨 사진을 전문적으로 판독하는 기능과는 다릅니다. 손글씨 사진은 일반 사진 OCR 경로로 처리되므로 정확도를 보장하지 않습니다.
2. 표 복원은 셀 경계·병합·다단 레이아웃을 이해하는 문서 레이아웃 모델이 아닌 위치 기반 추정입니다. 복잡한 표의 정확성을 보장하지 않습니다.
3. 자동 문서 검출은 OpenCV 윤곽선 휴리스틱입니다. 배경과 문서 경계가 비슷하면 검출에 실패할 수 있습니다.
4. 검색 가능한 이미지 PDF의 현재 UI 내보내기는 한 장의 현재 이미지에 대응합니다. 일반 PDF 내보내기는 수정된 텍스트를 여러 페이지로 나누어 저장합니다.
5. 원본 이미지에서 글자 색을 추정하는 과정은 샘플링 휴리스틱입니다. 색상 정확도 및 PDF 뷰어별 투명 텍스트 검색 동작은 다를 수 있습니다.
6. 삼성 내 파일 앱 자체의 비공개 API를 직접 호출하지 않습니다. Android Storage Access Framework 문서 선택기를 사용하며, 기기에 설치된 문서 제공자 중 내 파일을 선택할 수 있습니다.

## 빌드

- Android Studio 최신 안정 버전 권장
- JDK 17
- Android SDK Platform 35
- Gradle 8.9 / Android Gradle Plugin 8.7.3

Android Studio에서 이 폴더를 열고 Gradle 동기화 후 `app > Tasks > build > assembleDebug`를 실행합니다.

명령행에서는 프로젝트 루트에서 다음을 실행합니다.

```bash
gradle --no-daemon assembleDebug
```

성공하면 `app/build/outputs/apk/debug/app-debug.apk`가 생성됩니다. GitHub 저장소에 푸시하거나 Actions의 `Build Android APK` 워크플로를 수동 실행해도 디버그 APK 아티팩트를 만들 수 있습니다.

## 테스트 상태

이 작업 환경에는 Android SDK와 Gradle 실행 파일이 없어 실제 Android 빌드, 에뮬레이터 실행, 삼성 기기 테스트를 수행하지 못했습니다. 따라서 APK 빌드 성공 또는 기기 동작을 검증했다고 주장하지 않습니다. 프로젝트를 Android Studio 또는 GitHub Actions에서 빌드한 뒤 컴파일 로그와 기기 테스트 결과로 마지막 검증이 필요합니다.
